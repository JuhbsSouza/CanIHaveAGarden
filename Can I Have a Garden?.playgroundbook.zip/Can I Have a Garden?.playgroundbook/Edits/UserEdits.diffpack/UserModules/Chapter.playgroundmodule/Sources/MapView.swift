import PlaygroundSupport
import SwiftUI

public struct MapView: View {
    @State var isNext = false
    @State private var isHover = false
    public init () {}
    public var body: some View {
        ZStack {
            
            //Background
            Color.white.ignoresSafeArea()
            
            VStack{
                Text("Select the line closest to your country:")
                    .foregroundColor(Color.black)
                    .font(.system(size: 35))
                
                //Map
                ZStack {
                    Image(uiImage: #imageLiteral(resourceName: "mapa2.png"))
                        .resizable()
                        .frame(width: 800, height: 400)
                        .padding()
                    
                    VStack {
                        ButtonArctic()
                        ButtonCancer()
                        ButtonEquator()
                        ButtonCapricorn()
                    }
                }
            }
        }
    }
}

public struct ButtonArctic: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.658136785, green: 0.7746616006, blue: 0.9976486564, alpha: 1.0)), Color.init (#colorLiteral(red: 0.0, green: 0.3813630939, blue: 0.9982447028, alpha: 1.0))]), startPoint: .top, endPoint:.bottom)
                .padding(-4)
                .opacity(0.4)
                .frame(width: 800, height: 100)
            
            Button(action: {
                isNext.toggle()
            }) {
                Text("Artic Circle")
                    .foregroundColor(Color.white)
                    .font(.system(size: 25))
            }
            .padding(10)
            .background(self.isHover ? Color.gray : Color.black)
            .cornerRadius(30.0)
            .shadow(color: Color.gray, radius: 10)
            .onHover { hover in
                self.isHover = hover
            }
            .fullScreenCover(isPresented: $isNext){
                ArcticView()
            }
        }
    }
}

public struct ButtonCancer: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.9564090371, green: 0.6415483356, blue: 0.7538323998, alpha: 1.0)), Color.init (#colorLiteral(red: 0.9023433924, green: 0.2320581675, blue: 0.4786583185, alpha: 1.0))]), startPoint: .top, endPoint:.bottom)
                .padding(-4)
                .opacity(0.4)
                .frame(width: 800, height: 90)
            
            Button(action: {
                isNext.toggle()
            }) {
                Text("Tropic of Cancer")
                    .foregroundColor(Color.white)
                    .font(.system(size: 25))
            }
            .padding(10)
            .background(self.isHover ? Color.gray : Color.black)
            .cornerRadius(30.0)
            .shadow(color: Color.gray, radius: 10)
            .onHover { hover in
                self.isHover = hover
            }
            .fullScreenCover(isPresented: $isNext){
                CancerView()                
            }
        }
    }
}

public struct ButtonEquator: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 1.005411148071289, green: 0.9739938378334045, blue: 0.5218314528465271, alpha: 1.0)), Color.init (#colorLiteral(red: 0.9947732091, green: 0.7808949351, blue: 0.0, alpha: 1.0))]), startPoint: .top, endPoint:.bottom)
                .padding(-4)
                .opacity(0.4)
                .frame(width: 800, height: 100)
            
            Button(action: {
                isNext.toggle()
            }) {
                Text("Equator line")
                    .foregroundColor(Color.white)
                    .font(.system(size: 25))
            }
            .padding(10)
            .background(self.isHover ? Color.gray : Color.black)
            .cornerRadius(30.0)
            .shadow(color: Color.gray, radius: 10)
            .onHover { hover in
                self.isHover = hover
            }
            .fullScreenCover(isPresented: $isNext){
                EquatorView()                
            }
        }
    }
}

public struct ButtonCapricorn: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        ZStack {
            LinearGradient(gradient: Gradient(colors: [Color.init(#colorLiteral(red: 0.6933748722, green: 0.8683621287, blue: 0.5471815467, alpha: 1.0)), Color.init (#colorLiteral(red: 0.308306247, green: 0.4779683352, blue: 0.1554028392, alpha: 1.0))]), startPoint: .top, endPoint:.bottom)
                .padding(-4)
                .opacity(0.4)
                .frame(width: 800, height: 90)
            
            Button(action: {
                isNext.toggle()
            }) {
                Text("Tropic of Capricorn")
                    .foregroundColor(Color.white)
                    .font(.system(size: 25))
            }
            .padding(10)
            .background(self.isHover ? Color.gray : Color.black)
            .cornerRadius(30.0)
            .shadow(color: Color.gray, radius: 10)
            .onHover { hover in
                self.isHover = hover
            }
            .fullScreenCover(isPresented: $isNext){
                CapricornView()                
            }
        }
    }
}
