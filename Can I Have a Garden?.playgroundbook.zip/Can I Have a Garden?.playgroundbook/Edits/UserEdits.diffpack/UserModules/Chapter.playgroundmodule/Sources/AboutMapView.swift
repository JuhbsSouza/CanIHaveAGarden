import PlaygroundSupport
import SwiftUI

public struct AboutMapView: View {
    @State var isNext = false
    @State private var isHover = false
    public init () {}
    public var body: some View {
        ZStack {
            //background
            Color.yellow.ignoresSafeArea()
            
            VStack{
                Image(uiImage: #imageLiteral(resourceName: "About.png"))
                    .padding()
                
                NextButton()
            }
            
        }
    }
}

public struct NextButton: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        Button(action: {
            isNext.toggle()
        }) {
            Text("Next")
                .padding(10)
                .foregroundColor(Color.white)
                .font(.system(size: 30))
        }
        .onHover { hover in
            self.isHover = hover
        }
        .scaleEffect(self.isHover ? 1.1 : 1)
        .fullScreenCover(isPresented: $isNext){
            MapView()
        }
    }
}
