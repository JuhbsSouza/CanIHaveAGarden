import PlaygroundSupport
import SwiftUI

public struct GameView: View {
    @State var isNext = false
    public init () {}
    public var body: some View {
        ZStack {
            //background
            Color.yellow.ignoresSafeArea()
            
            VStack{
                Image(uiImage: #imageLiteral(resourceName: "Can I Have a Garden_.png"))
                    .resizable()
                    .frame(width: 500, height: 50)
                    .animation(.easeInOut(duration: 1.5))
                    .padding()
                
                Image(uiImage: #imageLiteral(resourceName: "planta2.png"))
                    .padding()
                
                GameButton()
            }
        }
    }
}

public struct GameButton: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        Button(action: {
            isNext.toggle()
        }) {
            Text("Start")
                .padding(20)
                .foregroundColor(Color.white)
                .font(.system(size: 35))
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 60, style: .circular)
                        .trim(from: self.isHover ? 0 : 1, to: 1)
                        .stroke(Color.white.opacity(1), lineWidth: 5)
        )
        
        .onHover { hover in
            self.isHover = hover
        }
        .scaleEffect(self.isHover ? 1.1 : 1)
        .fullScreenCover(isPresented: $isNext){
            AboutMapView()
        }
    }
}
