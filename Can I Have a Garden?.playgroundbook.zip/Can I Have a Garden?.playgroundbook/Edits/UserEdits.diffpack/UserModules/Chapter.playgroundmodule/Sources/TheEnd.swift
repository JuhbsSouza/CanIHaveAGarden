import PlaygroundSupport
import SwiftUI

public struct TheEndView: View {
    public init () {}
    public var body: some View {
        
        ZStack {
            
            //Background
            VStack {
                Color.yellow.edgesIgnoringSafeArea(.all)
            }
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "final4.png"))
                
                RestartButton()
            }
        }
    }
}

public struct RestartButton: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        Button(action: {
            isNext.toggle()
        }) {
            Text("Restart")
                .padding(10)
                .foregroundColor(Color.white)
                .font(.system(size: 30))
        }
        .padding()
        .onHover { hover in
            self.isHover = hover
        }
        .scaleEffect(self.isHover ? 1.1 : 1)
        .fullScreenCover(isPresented: $isNext){
            MapView()
        }
    }
}
