import PlaygroundSupport
import SwiftUI

public struct ArcticView: View {
    public init () {}
    public var body: some View {
        
        ZStack {
            
            //Background
            VStack {
                Color.yellow.edgesIgnoringSafeArea(.all)
            }
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "Arctic 1.png"))
                
                TheEndButton()
                
            }
        }
    }
}

public struct CancerView: View {
    public init () {}
    public var body: some View {
        
        ZStack {
            
            //Background
            VStack {
                Color.yellow.edgesIgnoringSafeArea(.all)
            }
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "Cancer 1.png"))
                
                TheEndButton()
            }
        }
    }
}

public struct EquatorView: View {
    public init () {}
    public var body: some View {
        
        ZStack {
            
            //Background
            VStack {
                Color.yellow.edgesIgnoringSafeArea(.all)
            }
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "Equator 1.png"))
                
                TheEndButton()
            }
        }
    }
}

public struct CapricornView: View {
    public init () {}
    public var body: some View {
        
        ZStack {
            
            //Background
            VStack {
                Color.yellow.edgesIgnoringSafeArea(.all)
            }
            VStack {
                Image(uiImage: #imageLiteral(resourceName: "Capricorn 1.png"))
                
                TheEndButton()
            }
        }
    }
}

public struct TheEndButton: View {
    @State var isNext = false
    @State private var isHover = false
    
    public init () {}
    public var body: some View {
        
        Button(action: {
            isNext.toggle()
        }) {
            Text("Next")
                .padding(10)
                .foregroundColor(Color.white)
                .font(.system(size: 30))
        }
        .onHover { hover in
            self.isHover = hover
        }
        .scaleEffect(self.isHover ? 1.1 : 1)
        .fullScreenCover(isPresented: $isNext){
            TheEndView()
        }
    }
}
