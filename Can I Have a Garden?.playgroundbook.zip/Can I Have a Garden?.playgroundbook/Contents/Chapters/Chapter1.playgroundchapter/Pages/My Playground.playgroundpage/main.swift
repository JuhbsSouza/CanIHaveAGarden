
/*:
 ## Hi! I'm Julia!
  
 I'm from Brazil, I'm 29 years old and I just started my journey as a developer student.
 I hope you create a good memory from this project that I created with so much love and tears ❤️😅.

# ✨So, what was my motivation for this project?✨
  
  
For many people around the world, home gardens are a tradition and sometimes a need. For others (like me, and probably you too) that ended up losing importance as a result of the economic evolution of society, the migration movements to the urban areas, added to the huge number of people working outside their houses, leading to the expansion of consumption of ultra-processed foods. But there are many ways and reasons to restore that millenary habit of having a garden. Even a really small one. 🪴
 
 
### The goal here is not to tell you ALL THE PLANTS that you can cultivate where you live. But to encourage you to start and maybe get excited and look for more and more options that suit your taste, habits, and your local variety of plants.
 
 
# Gardens as a source for a quality life
## 🌿 5 reasons to start doing it 🌿⬇️
 
 
### 1 ➡️ It's FUN!🥳 No matter how old you are
 

### 2 ➡️ Taking care of a garden brings a sense of routine. And is dynamic: no day is the same as another!😌
 

### 3 ➡️ It's an extra incentive to cook fresh food at home 😋
 

### 4 ➡️ It's a very rewarding experience ✅
 

### 5 ➡️ It is an opportunity to eat more variety and healthier food 🥬
 
*/

/*:

Please use "hide results" for a better experience.
 
# Now, let's play! 🥳

*/
